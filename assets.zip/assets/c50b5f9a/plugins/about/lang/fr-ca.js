﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'fr-ca', {
	copy: 'Copyright &copy; $1. Tous droits réservés.',
	dlgTitle: 'À propos de CKEditor',
	help: 'Consulter $1 pour l\'aide.',
	moreInfo: 'Pour les informations de licence, consulter notre site internet:',
	title: 'À propos de CKEditor',
	userGuide: 'Guide utilisateur de CKEditor'
});
