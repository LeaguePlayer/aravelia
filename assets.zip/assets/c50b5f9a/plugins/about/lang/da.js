﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'da', {
	copy: 'Copyright &copy; $1. Alle rettigheder forbeholdes.',
	dlgTitle: 'Om CKEditor',
	help: 'Se $1 for at få hjælp.',
	moreInfo: 'For informationer omkring licens, se venligst vores hjemmeside (på engelsk):',
	title: 'Om CKEditor',
	userGuide: 'CKEditor-brugermanual'
});
