﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'ku', {
	copy: 'مافی لەبەرگەرتنەوەی &copy; $1. گشتی پارێزراوه.',
	dlgTitle: 'دەربارەی CKEditor',
	help: 'سەیری $1 بکه بۆ یارمەتی.',
	moreInfo: 'بۆ زانیاری زیاتری مۆڵەت, تکایه سەردانی ماڵپەڕەکەمان بکه:',
	title: 'دەربارەی CKEditor',
	userGuide: 'ڕێپیشاندەری CKEditors'
});
