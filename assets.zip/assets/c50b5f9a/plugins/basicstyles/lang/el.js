﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'el', {
	bold: 'Έντονα',
	italic: 'Πλάγια',
	strike: 'Διαγράμμιση',
	subscript: 'Δείκτης',
	superscript: 'Εκθέτης',
	underline: 'Υπογράμμιση'
});
