﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'si', {
	bold: 'තද අකුරින් ලියනලද',
	italic: 'බැධීඅකුරින් ලියන ලද',
	strike: 'Strike Through', // MISSING
	subscript: 'Subscript', // MISSING
	superscript: 'Superscript', // MISSING
	underline: 'යටින් ඉරි අදින ලද'
});
